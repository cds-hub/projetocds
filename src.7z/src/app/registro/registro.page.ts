import { Component, OnInit } from '@angular/core';
import { NavController, NavParams } from '@ionic/angular';
import{} from 'ionic-angular';
import { AngularFireAuth } from 'angularfire2/auth';


export class User {
  email: string;
  password: string;
}


@Component({
selector: 'app-registro',
templateUrl: './registro.page.html',
styleUrls: ['./registro.page.scss'],
})
export class RegistroPage {

public user:User = new User();

constructor(public navCtrl: NavController, public navParams: NavParams,public fAuth: AngularFireAuth){
}


async registro() {
  try {
    var r = await this.fAuth.auth.createUserWithEmailAndPassword(
      this.user.email,
      this.user.password
    );
    if (r) {
      console.log("sucesso Registrado!");

      //aonde esta "navigateRoot" estava escrito "setRoot" mais nao funcionou
      this.navCtrl.navigateRoot('LoginPage');
    }

  } catch (err) {
    console.error(err);
  }
}
}
